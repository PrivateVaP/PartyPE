<?php
namespace PartyPE\Commands;
use PartyPE\Main;
use PartyPE\Commands\BaseCommand;
use pocketmine\command\CommandSender;
use pocketmine\OfflinePlayer;
use pocketmine\Player;
use pocketmine\utils\TextFormat as TF;
use pocketmine\utils\Config;
class MainPartyCommand extends BaseCommand {
    private $plugin;
    public $config;
    public $player;
    /**
     * MainPartyCommand constructor.
     * @param Main $plugin
     */
    public function __construct(Main $plugin) {
        $this->plugin = $plugin;
        parent::__construct($plugin, "party", "The main PartyPE command. /party help", ["party", "p", "par"]);
    }
    /**
     * @param CommandSender $sender
     * @param string $commandLabel
     * @param array $args
     */
    public function execute(CommandSender $sender, $commandLabel, array $args)
    {
        if($sender instanceof Player){
            if(count($args) < 1 ){
                $sender->sendMessage(TF::RED.'Usage: '. $this->getUsage());
                return false;
            }
                
                $sname = $sender->getName();
                $player = $this->plugin->getServer()->getPlayer($args[0]);
            
                switch(strtolower($args[0])) {
                    case 'help':
                    case '?':
                        /*
                        * Show help
                        */
                        $sender->sendMessage("--=[ PartyPE Help ]=---" . PHP_EOL . TF::DARK_PURPLE . "/party help" . TF::GOLD . " - " . TF::DARK_PURPLE . "Shows this menu" . PHP_EOL . TF::DARK_PURPLE . "/party create" . TF::GOLD . " - " . TF::DARK_PURPLE . "Creates a party" . PHP_EOL . TF::DARK_PURPLE . "/party inv" . TF::GOLD . " - " . TF::DARK_PURPLE . "Invites a player to your party" . PHP_EOL . TF::DARK_PURPLE . "/party stop" . TF::GOLD . " - " . TF::DARK_PURPLE . "Stops your party");
                        break;
                    case 'create':
                        /*
                        * Create a party
                        */
                        break;
                    case 'invite':
                    case 'inv':
                        /*
                        * Invite a player
                        */
                        if(!$player){
                            $sender->sendMessage(TF::RED.'That player is not online!');
                            return false;
                        }
                        if($this->plugin->getParty($player)){
                            $sender->sendMessage(TF::RED."That player is already in a party!");
                            return false;
                        }
                        if($this->plugin->isInParty($sender)){
                            if($this->plugin->getRank($sender) != "leader"){
                                $sender->sendMessage(TF::RED."Only the leader can invite people!");
                                return false;
                            }
                        }
                        $pname = $player->getName();
                        break;
                    case 'delete':
                    case 'del':
                    case 'stop':
                        /*
                        * Stop / Delete a party
                        */
                        break;
                }
        }
        else {
            $sender->sendMessage(TF::RED."Run this command in-game!");
        }
    }
    /**
     * @return mixed
     */
    public function getPlugin()
    {
        return $this->plugin;
    }
}