<?php
namespace PartyPE\Commands;
use PartyPE\Main;
use pocketmine\command\CommandSender;
use pocketmine\command\PluginCommand;
class BaseCommand extends PluginCommand {
    private $plugin;
    public function __construct(Main $plugin, $name, $description, $usageMessage, $aliases)
    {
        parent::__construct($name, $description, $usageMessage, $aliases);
        $this->plugin = $plugin;
    }
    /**
     * @param CommandSender $sender
     * @param string $commandLabel
     * @param string[] $args
     *
     * @return mixed
     */
    public function execute(CommandSender $sender, $commandLabel, array $args)
    {
        
  }